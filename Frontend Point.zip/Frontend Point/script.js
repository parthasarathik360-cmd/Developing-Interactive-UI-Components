"use strict";



function initializeAccordion(selector) {

    try {

        const accordion = document.querySelector(selector);

        if (!accordion) {
            console.warn(
                `Accordion element "${selector}" was not found.`
            );
            return;
        }

        const buttons = accordion.querySelectorAll(".faq-button");

        if (!buttons.length) {
            console.warn("No FAQ buttons were found.");
            return;
        }



        function openItem(button) {

            const item = button.closest(".faq-item");
            const answerId = button.getAttribute("aria-controls");
            const answer = document.getElementById(answerId);

            if (!item || !answer) {
                console.warn("Accordion item or answer element is missing.");
                return;
            }

            buttons.forEach((otherButton) => {

                if (otherButton !== button) {
                    closeItem(otherButton);
                }

            });

            button.setAttribute("aria-expanded", "true");

            item.classList.add("active");

            answer.hidden = false;
        }



        function closeItem(button) {

            const item = button.closest(".faq-item");
            const answerId = button.getAttribute("aria-controls");
            const answer = document.getElementById(answerId);

            if (!item || !answer) {
                return;
            }

            button.setAttribute("aria-expanded", "false");

            item.classList.remove("active");

            answer.hidden = true;
        }



        function toggleItem(button) {

            const expanded =
                button.getAttribute("aria-expanded") === "true";

            if (expanded) {
                closeItem(button);
            } else {
                openItem(button);
            }
        }


        buttons.forEach((button) => {

            button.addEventListener("click", () => {
                toggleItem(button);
            });

        });


        buttons.forEach((button, index) => {

            button.addEventListener("keydown", (event) => {

                let nextIndex;

                switch (event.key) {

                    case "ArrowDown":

                        event.preventDefault();

                        nextIndex =
                            (index + 1) % buttons.length;

                        buttons[nextIndex].focus();

                        break;


                    case "ArrowUp":

                        event.preventDefault();

                        nextIndex =
                            (index - 1 + buttons.length) %
                            buttons.length;

                        buttons[nextIndex].focus();

                        break;


                    case "Home":

                        event.preventDefault();

                        buttons[0].focus();

                        break;


                    case "End":

                        event.preventDefault();

                        buttons[buttons.length - 1].focus();

                        break;


                    case "Enter":
                    case " ":

                        event.preventDefault();

                        toggleItem(button);

                        break;

                    default:
                        break;
                }

            });

        });



        buttons.forEach((button) => {

            const answerId =
                button.getAttribute("aria-controls");

            const answer =
                document.getElementById(answerId);

            if (!answer) {
                return;
            }

            const expanded =
                button.getAttribute("aria-expanded") === "true";

            answer.hidden = !expanded;

        });


        console.log("FAQ accordion initialized successfully.");

    } catch (error) {


        console.error(
            "Unable to initialize FAQ accordion:",
            error
        );

    }
}


document.addEventListener("DOMContentLoaded", () => {

    initializeAccordion("#faqAccordion");

});